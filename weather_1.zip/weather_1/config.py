from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
INPUT_DIR = DATA_DIR / "input"
PROCESSED_DIR = DATA_DIR / "processed"
REPORTS_DIR = BASE_DIR / "reports"
CHARTS_DIR = REPORTS_DIR / "charts"
EXPORTS_DIR = REPORTS_DIR / "exports"
LOGS_DIR = BASE_DIR / "logs"

DEFAULT_THRESHOLDS = {
    "high_temperature": 35.0,
    "low_temperature": 5.0,
    "heavy_rainfall": 50.0,
    "high_humidity": 90.0,
    "high_wind_speed": 15.0,
}

for directory in (
    DATA_DIR,
    INPUT_DIR,
    PROCESSED_DIR,
    REPORTS_DIR,
    CHARTS_DIR,
    EXPORTS_DIR,
    LOGS_DIR,
):
    directory.mkdir(parents=True, exist_ok=True)
