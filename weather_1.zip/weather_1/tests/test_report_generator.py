import pandas as pd

from src.report_generator import build_report_data, export_report
from src.weather_analysis import WeatherAnalysis


def test_export_formats(tmp_path):
    df = pd.DataFrame({
        "date": pd.to_datetime(["2026-01-01"]),
        "temperature": [25],
    })
    analysis = WeatherAnalysis(df)
    anomalies = analysis.detect_anomalies()
    report = build_report_data(
        "Test Weather Report", df, analysis, anomalies, [],
        ["Test insight"],
    )
    paths = export_report(report, tmp_path)
    for suffix in ("json", "md", "txt", "csv"):
        assert suffix in paths
        assert paths[suffix].exists()
