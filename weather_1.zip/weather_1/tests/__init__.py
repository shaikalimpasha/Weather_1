"""Test suite for the Weather Data Visualizer."""
