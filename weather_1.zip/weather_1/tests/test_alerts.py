import pandas as pd

from src.alerts import generate_alerts


def test_threshold_alert_generation():
    df = pd.DataFrame({
        "date": pd.to_datetime(["2026-01-01"]),
        "city": ["Delhi"],
        "temperature": [40],
        "rainfall": [60],
        "humidity": [95],
        "wind_speed": [20],
    })
    thresholds = {
        "high_temperature": 35,
        "low_temperature": 5,
        "heavy_rainfall": 50,
        "high_humidity": 90,
        "high_wind_speed": 15,
    }
    alerts = generate_alerts(df, thresholds)
    assert len(alerts) == 4
    assert all("not an official warning" in alert["message"] for alert in alerts)
