import pandas as pd

from src.data_cleaner import clean_weather_data


def test_cleaner_removes_duplicates_and_invalid_dates():
    df = pd.DataFrame({
        "date": ["2026-01-01", "2026-01-01", "not-a-date"],
        "temperature": ["25", "25", "30"],
        "humidity": [50, 50, 110],
    })
    result = clean_weather_data(df)
    assert len(result.data) == 1
    assert result.duplicate_count == 1
    assert result.invalid_dates == 1
    assert "humidity" in result.data


def test_numeric_values_are_coerced():
    df = pd.DataFrame({"temperature": ["bad", 22.5], "rainfall": [-2, 3]})
    result = clean_weather_data(df)
    assert pd.isna(result.data.loc[0, "temperature"])
    assert result.data["rainfall"].min() >= 0
