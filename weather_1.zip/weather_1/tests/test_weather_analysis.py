import pandas as pd

from src.weather_analysis import WeatherAnalysis


def test_temperature_and_rainfall_statistics():
    df = pd.DataFrame({
        "date": pd.to_datetime(["2026-01-01", "2026-01-02"]),
        "temperature": [20, 30],
        "rainfall": [5, 15],
        "humidity": [40, 80],
        "wind_speed": [4, 8],
    })
    analysis = WeatherAnalysis(df)
    stats = analysis.statistics()
    assert stats["temperature"]["average"] == 25
    assert stats["temperature"]["minimum"] == 20
    assert stats["temperature"]["maximum"] == 30
    assert stats["total_rainfall"] == 20


def test_anomaly_detection_marks_obvious_outlier():
    df = pd.DataFrame({
        "temperature": [20, 21, 20, 21, 20, 100],
    })
    anomalies = WeatherAnalysis(df).detect_anomalies(z_threshold=2)
    assert len(anomalies) == 1
    assert anomalies.iloc[0]["measurement"] == "temperature"


def test_empty_dataframe_is_handled():
    analysis = WeatherAnalysis(pd.DataFrame())
    assert analysis.statistics()["record_count"] == 0
    assert analysis.daily_summary().empty
