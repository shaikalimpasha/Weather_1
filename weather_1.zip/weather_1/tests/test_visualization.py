import pandas as pd

from src import visualization


def test_temperature_chart_generation(tmp_path):
    df = pd.DataFrame({
        "date": pd.to_datetime(["2026-01-01", "2026-01-02"]),
        "temperature": [20, 22],
    })
    path = visualization.temperature_trend(df, tmp_path / "temperature.png")
    assert path.exists()
    assert path.stat().st_size > 0


def test_dashboard_handles_missing_optional_columns(tmp_path):
    df = pd.DataFrame({"date": pd.to_datetime(["2026-01-01"])})
    path = visualization.dashboard(df, tmp_path / "dashboard.png")
    assert path.exists()
