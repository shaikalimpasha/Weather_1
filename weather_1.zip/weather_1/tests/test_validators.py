from src.validators import normalize_columns, validate_file_path


def test_column_normalization():
    mapping = normalize_columns(["Date", "Max Temperature", "Wind Speed"])
    assert mapping == {
        "Date": "date",
        "Max Temperature": "maximum_temperature",
        "Wind Speed": "wind_speed",
    }


def test_validate_rejects_unsupported_extension(tmp_path):
    path = tmp_path / "weather.txt"
    path.write_text("test", encoding="utf-8")
    try:
        validate_file_path(path)
    except ValueError as exc:
        assert "Only .csv" in str(exc)
    else:
        raise AssertionError("Unsupported extension was accepted")
