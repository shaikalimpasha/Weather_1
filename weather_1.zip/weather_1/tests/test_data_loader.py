import json

import pandas as pd
import pytest

from src.data_loader import load_weather_data


def test_load_csv_normalizes_columns(tmp_path):
    path = tmp_path / "weather.csv"
    path.write_text(
        "Date,City,Temperature,Rainfall\n"
        "2026-01-01,Hyderabad,25,2\n",
        encoding="utf-8",
    )
    df = load_weather_data(path)
    assert list(df.columns) == ["date", "city", "temperature", "rainfall"]


def test_load_json(tmp_path):
    path = tmp_path / "weather.json"
    path.write_text(json.dumps([
        {"Date": "2026-01-01", "City": "Delhi", "Humidity": 65}
    ]), encoding="utf-8")
    df = load_weather_data(path)
    assert df.loc[0, "city"] == "Delhi"
    assert "humidity" in df


def test_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_weather_data(tmp_path / "missing.csv")


def test_empty_csv_raises(tmp_path):
    path = tmp_path / "empty.csv"
    path.write_text("", encoding="utf-8")
    with pytest.raises(ValueError):
        load_weather_data(path)
