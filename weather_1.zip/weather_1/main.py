import logging
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import config
from src.alerts import generate_alerts
from src.data_cleaner import clean_weather_data
from src.data_loader import load_weather_data
from src.report_generator import build_report_data, export_report
from src.utils import setup_logging
from src.weather_analysis import WeatherAnalysis
from src import visualization


class WeatherApplication(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Weather Data Visualizer and Analysis System")
        self.geometry("1180x760")
        self.minsize(900, 620)
        self.df = None
        self.canvas = None
        self.logger = setup_logging(config.LOGS_DIR / "weather_app.log")
        self.configure(bg="#F4F7FB")
        self._build_ui()

    def _build_ui(self) -> None:
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background="#F4F7FB")
        style.configure("TLabel", background="#F4F7FB", foreground="#243447")
        style.configure("Header.TLabel", font=("Segoe UI", 18, "bold"),
                        foreground="#1F4E79", background="#F4F7FB")
        style.configure("Card.TFrame", background="white")
        style.configure("TButton", font=("Segoe UI", 10), padding=6)

        header = ttk.Frame(self)
        header.pack(fill="x", padx=16, pady=(12, 8))
        ttk.Label(header, text="Weather Data Visualizer",
                  style="Header.TLabel").pack(side="left")
        ttk.Label(header, text="Academic Mini-Project",
                  foreground="#6B7C93").pack(side="right")

        toolbar = ttk.Frame(self)
        toolbar.pack(fill="x", padx=16, pady=6)
        ttk.Button(toolbar, text="Import CSV / JSON",
                   command=self.import_data).pack(side="left", padx=(0, 6))
        ttk.Button(toolbar, text="Export Reports",
                   command=self.export_reports).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Clean and Analyze",
                   command=self.analyze).pack(side="left", padx=6)

        threshold_frame = ttk.LabelFrame(toolbar, text="Configurable Thresholds")
        threshold_frame.pack(side="right")
        self.threshold_entries = {}
        labels = {
            "high_temperature": "High temperature",
            "low_temperature": "Low temperature",
            "heavy_rainfall": "Heavy rainfall",
            "high_humidity": "High humidity",
            "high_wind_speed": "High wind",
        }
        for index, (key, label) in enumerate(labels.items()):
            ttk.Label(threshold_frame, text=label).grid(
                row=0, column=index * 2, padx=(5, 2), pady=4
            )
            entry = ttk.Entry(threshold_frame, width=7)
            entry.insert(0, str(config.DEFAULT_THRESHOLDS[key]))
            entry.grid(row=0, column=index * 2 + 1, padx=(2, 5), pady=4)
            self.threshold_entries[key] = entry

        content = ttk.Frame(self)
        content.pack(fill="both", expand=True, padx=16, pady=8)
        content.columnconfigure(0, weight=1)
        content.columnconfigure(1, weight=3)
        content.rowconfigure(0, weight=1)

        left = ttk.Frame(content)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        right = ttk.Frame(content)
        right.grid(row=0, column=1, sticky="nsew")

        summary_card = ttk.LabelFrame(left, text="Dataset Summary")
        summary_card.pack(fill="x", pady=(0, 8))
        self.summary = tk.Text(summary_card, height=12, wrap="word",
                               font=("Consolas", 10), relief="flat",
                               background="#FFFFFF", foreground="#243447")
        self.summary.pack(fill="both", expand=True, padx=8, pady=8)

        action_card = ttk.LabelFrame(left, text="Analysis and Charts")
        action_card.pack(fill="both", expand=True)
        chart_buttons = [
            ("Temperature Trend", self.show_temperature),
            ("Rainfall", self.show_rainfall),
            ("Humidity and Wind", self.show_humidity_wind),
            ("Distribution", self.show_distribution),
            ("Correlation", self.show_correlation),
            ("Dashboard", self.show_dashboard),
        ]
        for label, command in chart_buttons:
            ttk.Button(action_card, text=label, command=command).pack(
                fill="x", padx=8, pady=3
            )

        chart_card = ttk.LabelFrame(right, text="Visualization")
        chart_card.pack(fill="both", expand=True)
        self.chart_area = ttk.Frame(chart_card)
        self.chart_area.pack(fill="both", expand=True)
        self.status = tk.StringVar(value="Ready. Import a CSV or JSON weather dataset.")
        ttk.Label(self, textvariable=self.status, anchor="w").pack(
            fill="x", padx=16, pady=(0, 8)
        )

    def _read_thresholds(self) -> dict[str, float]:
        thresholds = {}
        for key, entry in self.threshold_entries.items():
            try:
                value = float(entry.get().strip())
            except ValueError as exc:
                raise ValueError(f"Threshold '{key}' must be a number.") from exc
            if value < 0:
                raise ValueError(f"Threshold '{key}' cannot be negative.")
            thresholds[key] = value
        return thresholds

    def import_data(self) -> None:
        path = filedialog.askopenfilename(
            title="Select weather data",
            filetypes=[("Weather data", "*.csv *.json"), ("CSV", "*.csv"),
                       ("JSON", "*.json")],
        )
        if not path:
            return
        try:
            raw = load_weather_data(path)
            result = clean_weather_data(raw)
            self.df = result.data
            text = (
                f"Records loaded: {len(result.data)}\n"
                f"Duplicates removed: {result.duplicate_count}\n"
                f"Invalid rows removed: {result.removed_count}\n"
                f"Invalid dates removed: {result.invalid_dates}\n"
            )
            if "date" in result.data:
                text += f"Date range: {result.data['date'].min().date()} to "
                text += f"{result.data['date'].max().date()}\n"
            if "city" in result.data:
                cities = ", ".join(sorted(result.data["city"].dropna().astype(str).unique()))
                text += f"Cities: {cities or 'Not provided'}\n"
            text += "\nColumns:\n" + "\n".join(
                f"- {column}" for column in result.data.columns
            )
            self.summary.delete("1.0", "end")
            self.summary.insert("1.0", text)
            self.status.set(f"Loaded and cleaned: {Path(path).name}")
            self.logger.info("Imported dataset %s (%d records)", path, len(result.data))
            self.analyze()
        except (ValueError, FileNotFoundError, OSError) as exc:
            self.logger.error("Import failed: %s", exc)
            messagebox.showerror("Import error", str(exc))
            self.status.set("Import failed.")

    def analyze(self) -> None:
        if self.df is None:
            messagebox.showinfo("No dataset", "Please import a CSV or JSON dataset first.")
            return
        try:
            thresholds = self._read_thresholds()
            analysis = WeatherAnalysis(self.df)
            anomalies = analysis.detect_anomalies()
            alerts = generate_alerts(self.df, thresholds)
            text = self.summary.get("1.0", "end")
            text += "\n\nAnalysis:\n"
            for key, value in analysis.statistics().items():
                text += f"- {key}: {value}\n"
            text += f"\nStatistical anomaly records: {len(anomalies)}"
            text += f"\nThreshold alert records: {len(alerts)}"
            text += "\n\nInsights:\n" + "\n".join(
                f"- {item}" for item in analysis.insights()
            )
            self.summary.delete("1.0", "end")
            self.summary.insert("1.0", text)
            self.status.set(
                f"Analysis complete: {len(anomalies)} anomaly records, "
                f"{len(alerts)} threshold alerts."
            )
        except ValueError as exc:
            messagebox.showerror("Invalid threshold", str(exc))

    def _show_figure(self, fig) -> None:
        if self.canvas is not None:
            self.canvas.get_tk_widget().destroy()
        self.canvas = FigureCanvasTkAgg(fig, master=self.chart_area)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        plt.close(fig)

    def show_temperature(self) -> None:
        if self.df is not None:
            path = config.CHARTS_DIR / "temperature_trend.png"
            saved = visualization.temperature_trend(self.df, path)
            self._show_image(saved)

    def show_rainfall(self) -> None:
        if self.df is not None:
            saved = visualization.rainfall_chart(
                self.df, config.CHARTS_DIR / "rainfall.png"
            )
            self._show_image(saved)

    def show_humidity_wind(self) -> None:
        if self.df is not None:
            saved = visualization.humidity_wind_chart(
                self.df, config.CHARTS_DIR / "humidity_wind.png"
            )
            self._show_image(saved)

    def show_distribution(self) -> None:
        if self.df is not None:
            saved = visualization.temperature_distribution(
                self.df, config.CHARTS_DIR / "temperature_distribution.png"
            )
            self._show_image(saved)

    def show_correlation(self) -> None:
        if self.df is not None:
            saved = visualization.correlation_heatmap(
                self.df, config.CHARTS_DIR / "correlation.png"
            )
            self._show_image(saved)

    def show_dashboard(self) -> None:
        if self.df is not None:
            saved = visualization.dashboard(
                self.df, config.CHARTS_DIR / "dashboard.png"
            )
            self._show_image(saved)

    def _show_image(self, path: Path) -> None:
        fig = plt.imread(str(path))
        from matplotlib.figure import Figure
        figure = Figure(figsize=(10, 6), dpi=100)
        axis = figure.subplots()
        axis.imshow(fig)
        axis.axis("off")
        self._show_figure(figure)
        self.status.set(f"Chart generated: {path.name}")

    def export_reports(self) -> None:
        if self.df is None:
            messagebox.showinfo("No dataset", "Please import a dataset first.")
            return
        try:
            thresholds = self._read_thresholds()
            analysis = WeatherAnalysis(self.df)
            anomalies = analysis.detect_anomalies()
            alerts = generate_alerts(self.df, thresholds)
            report = build_report_data(
                "Weather Data Visualizer and Analysis System",
                self.df,
                analysis,
                anomalies,
                alerts,
                analysis.insights(),
            )
            paths = export_report(report, config.EXPORTS_DIR)
            names = ", ".join(path.name for path in paths.values())
            messagebox.showinfo("Reports exported", names)
            self.status.set(f"Exported {len(paths)} report formats.")
            self.logger.info("Exported reports: %s", names)
        except ValueError as exc:
            messagebox.showerror("Export error", str(exc))


def main() -> None:
    app = WeatherApplication()
    app.mainloop()


if __name__ == "__main__":
    main()
