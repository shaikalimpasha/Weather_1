# Sample Dataset

`sample_weather.csv` is synthetic demonstration data created for development and testing.
It does not represent real-world weather observations and must not be used as official data.
