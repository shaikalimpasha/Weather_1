import json
from datetime import datetime
from pathlib import Path

import pandas as pd

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
except ImportError:
    A4 = None


def build_report_data(title: str, df: pd.DataFrame, analysis, anomalies, alerts,
                      insights: list[str]) -> dict:
    return {
        "title": title,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "dataset": {
            "total_records": len(df),
            "date_range": (
                [str(df["date"].min()), str(df["date"].max())]
                if "date" in df and not df["date"].isna().all()
                else None
            ),
            "cities": (
                sorted(df["city"].dropna().astype(str).unique().tolist())
                if "city" in df else []
            ),
        },
        "statistics": analysis.statistics(),
        "insights": insights,
        "anomalies": anomalies.to_dict(orient="records"),
        "alerts": alerts,
    }


def export_report(report: dict, exports_dir: str | Path) -> dict[str, Path]:
    directory = Path(exports_dir)
    directory.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    paths = {}
    for suffix, writer in (
        ("json", lambda p: p.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")),
    ):
        path = directory / f"weather_report_{stamp}.{suffix}"
        writer(path)
        paths[suffix] = path

    lines = [
        f"# {report['title']}",
        "",
        f"Generated: {report['generated_at']}",
        f"Total records: {report['dataset']['total_records']}",
        "",
        "## Dataset",
        f"Date range: {report['dataset']['date_range']}",
        f"Cities: {', '.join(report['dataset']['cities']) or 'Not provided'}",
        "",
        "## Statistics",
        json.dumps(report["statistics"], indent=2),
        "",
        "## Insights",
    ]
    lines.extend(f"- {item}" for item in report["insights"])
    lines.extend(["", "## Statistical anomalies"])
    lines.extend(
        f"- {item}" if isinstance(item, str) else f"- {json.dumps(item, default=str)}"
        for item in report["anomalies"]
    )
    lines.extend(["", "## Threshold alerts"])
    lines.extend(f"- {json.dumps(item, default=str)}" for item in report["alerts"])

    md_path = directory / f"weather_report_{stamp}.md"
    md_path.write_text("\n".join(lines), encoding="utf-8")
    paths["md"] = md_path

    txt_path = directory / f"weather_report_{stamp}.txt"
    txt_path.write_text("\n".join(line for line in lines if not line.startswith("#")),
                      encoding="utf-8")
    paths["txt"] = txt_path

    csv_path = directory / f"weather_report_{stamp}.csv"
    pd.DataFrame([{
        "title": report["title"],
        "generated_at": report["generated_at"],
        "total_records": report["dataset"]["total_records"],
        "statistics": json.dumps(report["statistics"]),
        "insights": " | ".join(report["insights"]),
        "anomalies_count": len(report["anomalies"]),
        "alerts_count": len(report["alerts"]),
    }]).to_csv(csv_path, index=False)
    paths["csv"] = csv_path

    if A4 is not None:
        pdf_path = directory / f"weather_report_{stamp}.pdf"
        document = SimpleDocTemplate(str(pdf_path), pagesize=A4)
        styles = getSampleStyleSheet()
        content = [Paragraph(report["title"], styles["Title"]), Spacer(1, 12)]
        content.append(Paragraph(
            f"Generated: {report['generated_at']}<br/>"
            f"Total records: {report['dataset']['total_records']}",
            styles["Normal"],
        ))
        content.append(Spacer(1, 12))
        content.append(Paragraph("Statistics", styles["Heading2"]))
        content.append(Paragraph(json.dumps(report["statistics"], indent=2).replace("\n", "<br/>"),
                                 styles["Code"]))
        content.append(Paragraph("Insights", styles["Heading2"]))
        for insight in report["insights"]:
            content.append(Paragraph(insight, styles["Normal"]))
        content.append(Paragraph("Threshold alerts", styles["Heading2"]))
        for alert in report["alerts"]:
            content.append(Paragraph(alert["message"], styles["Normal"]))
        document.build(content)
        paths["pdf"] = pdf_path
    return paths
