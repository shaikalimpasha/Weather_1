from typing import Mapping

import pandas as pd


ALERT_COLUMNS = {
    "high_temperature": ("temperature", ">"),
    "low_temperature": ("temperature", "<"),
    "heavy_rainfall": ("rainfall", ">"),
    "high_humidity": ("humidity", ">"),
    "high_wind_speed": ("wind_speed", ">"),
}


def generate_alerts(df: pd.DataFrame, thresholds: Mapping[str, float]) -> list[dict]:
    alerts = []
    for name, (column, operator) in ALERT_COLUMNS.items():
        if column not in df or name not in thresholds:
            continue
        threshold = float(thresholds[name])
        if threshold < 0:
            continue
        series = pd.to_numeric(df[column], errors="coerce")
        selected = series > threshold if operator == ">" else series < threshold
        for index in df.index[selected.fillna(False)]:
            alerts.append({
                "alert": name.replace("_", " ").title(),
                "date": df.loc[index, "date"] if "date" in df else None,
                "city": df.loc[index, "city"] if "city" in df else None,
                "measurement": column,
                "value": round(float(series.loc[index]), 2),
                "threshold": threshold,
                "message": (
                    f"{column.replace('_', ' ').title()} {operator} "
                    f"{threshold:.1f}: observed {series.loc[index]:.1f}. "
                    "This is an application threshold alert, not an official warning."
                ),
            })
    return alerts
