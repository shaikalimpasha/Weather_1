from __future__ import annotations

import numpy as np
import pandas as pd


class WeatherAnalysis:
    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()
        self.numeric_columns = [
            column for column in (
                "temperature", "minimum_temperature", "maximum_temperature",
                "humidity", "rainfall", "wind_speed", "pressure",
            ) if column in self.df.columns
        ]

    def statistics(self) -> dict:
        result = {"record_count": int(len(self.df))}
        for column in self.numeric_columns:
            series = pd.to_numeric(self.df[column], errors="coerce").dropna()
            if series.empty:
                result[column] = None
                continue
            result[column] = {
                "average": round(float(series.mean()), 2),
                "minimum": round(float(series.min()), 2),
                "maximum": round(float(series.max()), 2),
            }
        if "temperature" in self.df:
            series = pd.to_numeric(self.df["temperature"], errors="coerce").dropna()
            result["temperature_variation"] = (
                round(float(series.max() - series.min()), 2) if not series.empty else None
            )
        if "rainfall" in self.df:
            result["total_rainfall"] = round(
                float(pd.to_numeric(self.df["rainfall"], errors="coerce").fillna(0).sum()), 2
            )
        return result

    def daily_summary(self) -> pd.DataFrame:
        if "date" not in self.df:
            return pd.DataFrame()
        return self.df.groupby("date", as_index=False)[self.numeric_columns].mean(numeric_only=True)

    def monthly_summary(self) -> pd.DataFrame:
        if "date" not in self.df:
            return pd.DataFrame()
        monthly = self.df.copy()
        monthly["month"] = monthly["date"].dt.to_period("M").astype(str)
        return monthly.groupby("month", as_index=False)[self.numeric_columns].mean(numeric_only=True)

    def detect_anomalies(self, z_threshold: float = 2.5) -> pd.DataFrame:
        anomalies = []
        candidate_columns = [
            "temperature", "rainfall", "humidity", "wind_speed"
        ]
        for column in candidate_columns:
            if column not in self.df:
                continue
            series = pd.to_numeric(self.df[column], errors="coerce")
            mean = series.mean()
            std = series.std()
            if pd.isna(std) or std == 0:
                continue
            z_scores = (series - mean) / std
            for index in self.df.index[z_scores.abs() > z_threshold]:
                value = series.loc[index]
                anomalies.append({
                    "date": self.df.loc[index, "date"] if "date" in self.df else None,
                    "city": self.df.loc[index, "city"] if "city" in self.df else None,
                    "measurement": column,
                    "value": round(float(value), 2),
                    "z_score": round(float(z_scores.loc[index]), 2),
                    "reason": f"{column} is an statistical outlier (|z| > {z_threshold}).",
                })
        return pd.DataFrame(anomalies)

    def trend(self, column: str) -> dict:
        if column not in self.df or "date" not in self.df:
            return {"direction": "unavailable", "change": None}
        series = pd.to_numeric(self.df[column], errors="coerce").dropna()
        if len(series) < 2:
            return {"direction": "insufficient data", "change": None}
        x = np.arange(len(series))
        slope = float(np.polyfit(x, series.to_numpy(), 1)[0])
        if abs(slope) < 1e-9:
            direction = "stable"
        else:
            direction = "increasing" if slope > 0 else "decreasing"
        return {"direction": direction, "change": round(slope, 4)}

    def insights(self) -> list[str]:
        insights = []
        if "temperature" in self.df:
            data = self.df.dropna(subset=["temperature"])
            if not data.empty:
                warm = data.loc[data["temperature"].idxmax()]
                cold = data.loc[data["temperature"].idxmin()]
                insights.append(
                    f"Warmest recorded temperature: {warm['temperature']:.1f} "
                    f"{'on ' + str(warm['date'].date()) if 'date' in data else ''}."
                )
                insights.append(
                    f"Coldest recorded temperature: {cold['temperature']:.1f} "
                    f"{'on ' + str(cold['date'].date()) if 'date' in data else ''}."
                )
        if "rainfall" in self.df:
            data = self.df.dropna(subset=["rainfall"])
            if not data.empty:
                wet = data.loc[data["rainfall"].idxmax()]
                insights.append(
                    f"Maximum rainfall: {wet['rainfall']:.1f} "
                    f"{'on ' + str(wet['date'].date()) if 'date' in data else ''}."
                )
        for column in ("temperature", "rainfall", "humidity", "wind_speed"):
            if column in self.df:
                trend = self.trend(column)
                insights.append(
                    f"{column.replace('_', ' ').title()} trend is {trend['direction']}."
                )
        return insights
