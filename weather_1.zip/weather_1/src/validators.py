from pathlib import Path
from typing import Iterable

import pandas as pd


SUPPORTED_EXTENSIONS = {".csv", ".json"}
CANONICAL_COLUMNS = {
    "date": "date",
    "city": "city",
    "temperature": "temperature",
    "temp": "temperature",
    "minimum_temperature": "minimum_temperature",
    "min_temperature": "minimum_temperature",
    "mintemp": "minimum_temperature",
    "maximum_temperature": "maximum_temperature",
    "max_temperature": "maximum_temperature",
    "maxtemp": "maximum_temperature",
    "humidity": "humidity",
    "rainfall": "rainfall",
    "rain": "rainfall",
    "precipitation": "rainfall",
    "wind_speed": "wind_speed",
    "windspeed": "wind_speed",
    "pressure": "pressure",
    "atmospheric_pressure": "pressure",
}


def validate_file_path(path: str | Path) -> Path:
    file_path = Path(path).expanduser()
    if not file_path.exists():
        raise FileNotFoundError(f"File does not exist: {file_path}")
    if not file_path.is_file():
        raise ValueError(f"Path is not a file: {file_path}")
    if file_path.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ValueError("Only .csv and .json weather data files are supported.")
    return file_path


def normalize_columns(columns: Iterable[str]) -> dict[str, str]:
    mapping = {}
    for column in columns:
        clean = str(column).strip().lower().replace(" ", "_").replace("-", "_")
        if clean in CANONICAL_COLUMNS:
            mapping[column] = CANONICAL_COLUMNS[clean]
    return mapping


def validate_numeric_ranges(df: pd.DataFrame) -> dict[str, list[int]]:
    issues: dict[str, list[int]] = {}
    ranges = {
        "humidity": (0, 100),
        "rainfall": (0, None),
        "pressure": (850, 1150),
        "wind_speed": (0, None),
    }
    for column, (minimum, maximum) in ranges.items():
        if column not in df.columns:
            continue
        series = pd.to_numeric(df[column], errors="coerce")
        invalid = series.lt(minimum) if minimum is not None else pd.Series(False, index=df.index)
        if maximum is not None:
            invalid = invalid | series.gt(maximum)
        if invalid.any():
            issues[column] = df.index[invalid.fillna(False)].astype(int).tolist()
    return issues
