from pathlib import Path

import pandas as pd

from src.validators import normalize_columns, validate_file_path


def load_weather_data(path: str | Path) -> pd.DataFrame:
    file_path = validate_file_path(path)
    try:
        if file_path.suffix.lower() == ".csv":
            df = pd.read_csv(file_path)
        else:
            df = pd.read_json(file_path)
        if df.empty:
            return df.rename(columns=normalize_columns(df.columns))
        return df.rename(columns=normalize_columns(df.columns))
    except pd.errors.EmptyDataError as exc:
        raise ValueError("The selected file is empty.") from exc
    except (pd.errors.ParserError, ValueError) as exc:
        raise ValueError(f"Unable to parse weather data: {exc}") from exc
