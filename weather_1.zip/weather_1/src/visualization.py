from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.figure import Figure


def save_chart(fig: Figure, output_path: str | Path) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path


def temperature_trend(df: pd.DataFrame, output_path: str | Path) -> Path:
    fig, ax = plt.subplots(figsize=(10, 5))
    if "date" not in df or "temperature" not in df:
        ax.text(0.5, 0.5, "Temperature and date data unavailable", ha="center", va="center")
    else:
        ax.plot(df["date"], df["temperature"], marker="o", linewidth=2, label="Temperature")
        if "minimum_temperature" in df:
            ax.plot(df["date"], df["minimum_temperature"], linewidth=1.5, label="Minimum")
        if "maximum_temperature" in df:
            ax.plot(df["date"], df["maximum_temperature"], linewidth=1.5, label="Maximum")
        ax.legend()
        ax.set_xlabel("Date")
        ax.set_ylabel("Temperature")
    ax.set_title("Temperature Trend")
    ax.grid(alpha=0.25)
    return save_chart(fig, output_path)


def rainfall_chart(df: pd.DataFrame, output_path: str | Path) -> Path:
    fig, ax = plt.subplots(figsize=(10, 5))
    if "date" not in df or "rainfall" not in df:
        ax.text(0.5, 0.5, "Rainfall and date data unavailable", ha="center", va="center")
    else:
        ax.bar(df["date"], df["rainfall"], color="#4C78A8")
        ax.set_xlabel("Date")
        ax.set_ylabel("Rainfall")
    ax.set_title("Daily Rainfall")
    ax.grid(axis="y", alpha=0.25)
    return save_chart(fig, output_path)


def humidity_wind_chart(df: pd.DataFrame, output_path: str | Path) -> Path:
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    for ax, column, title, color in (
        (ax1, "humidity", "Humidity Trend", "#59A14F"),
        (ax2, "wind_speed", "Wind Speed Trend", "#F28E2B"),
    ):
        if "date" in df and column in df:
            ax.plot(df["date"], df[column], marker="o", color=color)
            ax.set_ylabel(title)
        else:
            ax.text(0.5, 0.5, f"{title} unavailable", ha="center", va="center")
        ax.grid(alpha=0.25)
    ax2.set_xlabel("Date")
    fig.suptitle("Humidity and Wind Analysis")
    return save_chart(fig, output_path)


def temperature_distribution(df: pd.DataFrame, output_path: str | Path) -> Path:
    fig, ax = plt.subplots(figsize=(10, 5))
    if "temperature" not in df:
        ax.text(0.5, 0.5, "Temperature data unavailable", ha="center", va="center")
    else:
        values = df["temperature"].dropna()
        ax.hist(values, bins="auto", color="#E45756", edgecolor="white")
        ax.set_xlabel("Temperature")
        ax.set_ylabel("Frequency")
    ax.set_title("Temperature Distribution")
    ax.grid(axis="y", alpha=0.25)
    return save_chart(fig, output_path)


def correlation_heatmap(df: pd.DataFrame, output_path: str | Path) -> Path:
    fig, ax = plt.subplots(figsize=(8, 6))
    columns = [
        c for c in (
            "temperature", "minimum_temperature", "maximum_temperature",
            "humidity", "rainfall", "wind_speed", "pressure",
        ) if c in df
    ]
    corr = df[columns].corr(numeric_only=True) if len(columns) >= 2 else pd.DataFrame()
    if corr.empty:
        ax.text(0.5, 0.5, "At least two numeric columns are required",
                ha="center", va="center")
    else:
        image = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1)
        ax.set_xticks(range(len(corr.columns)), corr.columns, rotation=45, ha="right")
        ax.set_yticks(range(len(corr.index)), corr.index)
        fig.colorbar(image, ax=ax)
    ax.set_title("Weather Correlation")
    return save_chart(fig, output_path)


def dashboard(df: pd.DataFrame, output_path: str | Path) -> Path:
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    ((ax1, ax2), (ax3, ax4)) = axes
    if "date" in df and "temperature" in df:
        ax1.plot(df["date"], df["temperature"], color="#E45756")
    ax1.set_title("Temperature")
    ax1.grid(alpha=0.25)
    if "date" in df and "rainfall" in df:
        ax2.bar(df["date"], df["rainfall"], color="#4C78A8")
    ax2.set_title("Rainfall")
    ax2.grid(axis="y", alpha=0.25)
    if "date" in df and "humidity" in df:
        ax3.plot(df["date"], df["humidity"], color="#59A14F")
    ax3.set_title("Humidity")
    ax3.grid(alpha=0.25)
    if "date" in df and "wind_speed" in df:
        ax4.plot(df["date"], df["wind_speed"], color="#F28E2B")
    ax4.set_title("Wind Speed")
    ax4.grid(alpha=0.25)
    fig.suptitle("Weather Dashboard")
    return save_chart(fig, output_path)
