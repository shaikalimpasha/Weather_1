import pandas as pd

from src.validators import validate_numeric_ranges


class CleaningResult:
    def __init__(self, data: pd.DataFrame, duplicate_count: int, removed_count: int,
                 invalid_dates: int, issues: dict):
        self.data = data
        self.duplicate_count = duplicate_count
        self.removed_count = removed_count
        self.invalid_dates = invalid_dates
        self.issues = issues


def clean_weather_data(df: pd.DataFrame) -> CleaningResult:
    if df is None:
        raise ValueError("No weather dataset was provided.")

    data = df.copy()
    duplicate_count = int(data.duplicated().sum())
    data = data.drop_duplicates()

    if "date" in data.columns:
        data["date"] = pd.to_datetime(data["date"], errors="coerce")
        invalid_dates = int(data["date"].isna().sum())
        data = data.dropna(subset=["date"])
    else:
        invalid_dates = 0

    if "city" in data.columns:
        data["city"] = data["city"].astype("string").str.strip()
        data.loc[data["city"].isin(["", "nan", "None"]), "city"] = pd.NA

    numeric_columns = [
        "temperature", "minimum_temperature", "maximum_temperature",
        "humidity", "rainfall", "wind_speed", "pressure",
    ]
    for column in numeric_columns:
        if column in data.columns:
            data[column] = pd.to_numeric(data[column], errors="coerce")

    issues = validate_numeric_ranges(data)
    for column in ("humidity", "rainfall", "wind_speed", "pressure"):
        if column not in issues:
            continue
        data[column] = data[column].where(
            pd.to_numeric(data[column], errors="coerce").notna()
        )
    if "humidity" in data.columns:
        data["humidity"] = data["humidity"].clip(0, 100)
    if "rainfall" in data.columns:
        data["rainfall"] = data["rainfall"].clip(lower=0)
    if "wind_speed" in data.columns:
        data["wind_speed"] = data["wind_speed"].clip(lower=0)

    if "date" in data.columns:
        data = data.sort_values("date")

    removed_count = int(len(df) - len(data))
    data = data.reset_index(drop=True)
    return CleaningResult(data, duplicate_count, removed_count, invalid_dates, issues)
