# Weather Data Visualizer and Analysis System

A professional desktop weather data analysis application built with Python, pandas, NumPy,
Matplotlib and Tkinter. The project supports CSV/JSON import, cleaning, weather statistics,
anomaly detection, configurable threshold alerts, chart generation and report exports.

## Objectives

- Provide reliable historical weather data analysis without real weather API dependencies.
- Separate data loading, cleaning, analysis, visualization, alerts and reporting.
- Offer beginner-friendly operation through a graphical interface.
- Demonstrate professional software engineering and automated testing practices.

## Features

- CSV and JSON import
- Column-name normalization and invalid-row handling
- Duplicate and invalid-date removal
- Numeric validation and range correction
- Temperature, rainfall, humidity, wind and pressure statistics
- Daily and monthly summaries
- Z-score anomaly detection
- Configurable application threshold alerts
- Temperature, rainfall, humidity, wind, distribution, correlation and dashboard charts
- Markdown, text, CSV, JSON and PDF report exports
- Logging and clear GUI error notifications

## Technologies

- Python 3
- Tkinter
- pandas
- NumPy
- Matplotlib
- pytest
- reportlab (optional PDF support)

## Installation in Windows VS Code

Open the project folder in VS Code, open a terminal, and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

If PowerShell blocks activation, use Command Prompt in VS Code or run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## Run the Application

```powershell
python main.py
```

Use **Import CSV / JSON**, select a dataset, then use the chart and report buttons.

The included `sample_data/sample_weather.csv` is clearly synthetic demonstration data.

## Data Format

Supported optional columns include:

- Date
- City
- Temperature
- Minimum Temperature
- Maximum Temperature
- Humidity
- Rainfall
- Wind Speed
- Atmospheric Pressure

The application recognizes common column-name variants, but the clearer the headers,
the easier the dataset is to process.

## Run Tests

```powershell
python -m pytest -q
```

## Project Structure

```text
weather_1/
  main.py
  config.py
  requirements.txt
  README.md
  data/
  src/
    data_loader.py
    data_cleaner.py
    weather_analysis.py
    visualization.py
    report_generator.py
    alerts.py
    validators.py
    utils.py
  reports/
  logs/
  sample_data/
  tests/
```

## Architecture

The application separates file loading, cleaning and validation, statistical analysis,
alert evaluation, chart generation and report export. This reduces coupling and makes
individual components testable.

## Alert and Anomaly Interpretation

Application alerts are threshold-based and do not represent official government warnings.
Anomaly detection uses z-scores and only identifies statistical outliers; it does not
confirm dangerous weather conditions.

## Limitations

- Historical CSV/JSON data is the primary input source.
- Statistical anomaly detection requires sufficient and valid numeric observations.
- PDF export requires reportlab.
- Official real-time weather information requires a separate provider and API policy.

## Future Enhancements

- City and date range filtering
- Database storage
- Optional weather API integration
- Export to Excel
- Improved interactive chart tools
